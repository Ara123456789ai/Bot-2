"""Tests for the trend-bar entry in trend_test.py. Run: python3 test_trend.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import trend_test as R

N = 120
P = dict(spread=0.021, point=0.001, sl=300, tp=500, tp_tint=500, min_run=5)


def make(patch=None):
    o = [100.0] * N; h = [100.0] * N; l = [100.0] * N; c = [100.0] * N
    for k, v in (patch or {}).items():
        o[k], h[k], l[k], c[k] = v
    X = R.Ctx()
    X.o, X.h, X.l, X.c, X.p = o, h, l, c, P
    X.ok = bytearray([1] * N); X.can = bytearray([1] * N); X.flat = bytes(N)
    X.sa = bytes(N); X.measure, X.bar_pts, X.prev = "body", 10, "low"
    X.ema1 = R.ema_series(c, X.ok, 1, 12); X.ema5 = R.ema_series(c, X.ok, 5, 12)
    return X


def trades(mode, X, a=5, b=100, el_a=20, el_b=90):
    act = bytes(1 if a <= k <= b else 0 for k in range(N))
    el = bytes(1 if el_a <= k <= el_b else 0 for k in range(N))
    return R.run(mode, act, el, X)


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (" " + extra if extra else ""))
    if not cond:
        sys.exit(1)


# a 12 point bear body, below the previous low and below the EMA -> enters at its close
X = make({30: (100.0, 100.0, 99.985, 99.988)})
t = trades("m1", X)
check("1m: 12 point bear bar below previous low and EMA enters at its close", len(t) == 1 and t[0][0] == 30 and abs(t[0][3] - (99.988 - 100.021)) < 1e-9, str(t))
# only a 9 point body: no entry
X = make({30: (100.0, 100.0, 99.985, 99.991)})
check("1m: a 9 point bar is not a trend bar", trades("m1", X) == [])
# bear bar that does not close below the previous low: no entry
X = make({29: (100.0, 100.0, 99.95, 99.96), 30: (99.97, 99.97, 99.955, 99.958)})
t = trades("m1", X)
check("1m: closing above the previous low is not enough", all(x[0] != 30 for x in t), str(t))
# price above the EMA: no entry
X = make({k: (101.0, 101.0, 101.0, 101.0) for k in range(10, 30)} | {30: (100.99, 100.99, 100.97, 100.975)})
X.ema1 = R.ema_series(X.c, X.ok, 1, 12)
t = trades("m1", X)
check("1m: a bar still above the EMA is skipped", all(x[0] != 30 for x in t), str(t))
# 5-minute bar (minutes 40-44): open 100.0, close 99.985, previous bar (35-39) low 100.0
X = make({40: (100.0, 100.0, 99.99, 99.99), 44: (99.99, 99.99, 99.98, 99.985)})
t = trades("m5", X)
check("5m: bear bar of 15 points closing below the previous 5-minute low enters at minute 44", len(t) == 1 and t[0][0] == 44, str(t))
# stop loss of 300 points after entry
X = make({30: (100.0, 100.0, 99.985, 99.988), 40: (99.99, 100.4, 99.99, 100.3)})
t = trades("m1", X)
check("1m: stop loss at 300 points", len(t) == 1 and t[0][2] == "SL" and abs(t[0][3] + 0.3) < 1e-9, str(t))
# take profit at 500
X = make({30: (100.0, 100.0, 99.985, 99.988), 40: (99.9, 99.9, 99.4, 99.45)})
t = trades("m1", X)
check("1m: take profit at 500 points", len(t) == 1 and t[0][2] == "TP" and abs(t[0][3] - 0.5) < 1e-9, str(t))
print("all trend tests passed")
